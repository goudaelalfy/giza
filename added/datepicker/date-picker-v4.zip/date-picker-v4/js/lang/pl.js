/* Please save this file using the appropriate two letter language code e.g. fr.js
and send it to frequency.decoder at gmail d0t com - thanks! */

var fdLocale = {
/* Uncomment the following line if the first day of the week does not start on Monday */
//firstDayOfWeek:0,
fullMonths:["Stycze\u0144", "Luty", "Marzec", "Kwiecie\u0144", "Maj", "Czerwiec", "Lipiec", "Sierpie\u0144", "Wrzesie\u0144", "Pa\u017Adziernik", "Listopad", "Grudzie\u0144"],
monthAbbrs:["Sty", "Lut", "Mar", "Kwi", "Maj", "Cze", "Lip", "Sie", "Wrz", "Pa\u017A", "Lis", "Gru"],
fullDays:["Poniedzia\u0142ek", "Wtorek", "\u015Aroda", "Czwartek", "Pi\u0105tek", "Sobota", "Niedziela"],
dayAbbrs:["Pon", "Wto", "\u015Aro", "Czw", "Pi\u0105", "Sob", "Nie"],
titles:["Poprzedni miesi\u0105c", "Nast\u0119pny miesi\u0105c", "Poprzedni rok", "Nast\u0119pny rok", "Dzi\u015B", "Poka\u017C kalendarz", "Tyd", "Tydzie\u0144 [[%0%]] z [[%1%]]", "Tydzie\u0144", "Wybierz dat\u0119", "Przeci\u0105gnij i upu\u015B\u0107", "Wy\u015Bwietla \u201C[[%0%]]\u201D Jako pierwszy", "Zaznacza dzie\u0144 dzisiejszy", "Data wy\u0142\u0105czona"]};
